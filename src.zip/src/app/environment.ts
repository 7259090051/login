export const environment = 
{
    production: false,
    API_URL: 'https://reqres.in/api',
};